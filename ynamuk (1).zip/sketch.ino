
#include <Wire.h>
#include <RTClib.h>
#include <DHT.h>
#include <LiquidCrystal_I2C.h>

// ===== PIN ESP32 =====
#define DHT_PIN 4
#define PIR_PIN 27
#define RELAY_PIN 23
#define LED_PIN 19
#define BUZZER_PIN 18

#define DHT_TYPE DHT22

// ===== OBJEK KOMPONEN =====
RTC_DS1307 rtc;
DHT dht(DHT_PIN, DHT_TYPE);
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Relay aktif LOW
const bool RELAY_ACTIVE_LOW = true;

// ===== JADWAL AKTIF =====
// Jadwal 1: 18:00 sampai sebelum 18:30
// Jadwal 2: 20:00 sampai sebelum 20:30
const int MULAI_1 = 18 * 60;
const int SELESAI_1 = 18 * 60 + 30;

const int MULAI_2 = 20 * 60;
const int SELESAI_2 = 20 * 60 + 30;

// ===== DATA SENSOR =====
float suhu = 0;
float kelembapan = 0;

bool sensorDHTValid = false;
bool statusRelaySebelumnya = false;

unsigned long waktuBacaSensor = 0;
unsigned long waktuLCD = 0;

// ===== CEK JADWAL =====
bool dalamJadwal(int jam, int menit) {
  int total = jam * 60 + menit;

  return
    (total >= MULAI_1 && total < SELESAI_1) ||
    (total >= MULAI_2 && total < SELESAI_2);
}

// ===== KONTROL RELAY =====
void aturRelay(bool aktif) {
  if (RELAY_ACTIVE_LOW) {
    digitalWrite(RELAY_PIN, aktif ? LOW : HIGH);
  } else {
    digitalWrite(RELAY_PIN, aktif ? HIGH : LOW);
  }
}

// ===== SETUP =====
void setup() {
  Serial.begin(115200);

  pinMode(PIR_PIN, INPUT);
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  aturRelay(false);
  digitalWrite(LED_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  // Tes LED saat ESP32 mulai:
  // LED seharusnya menyala selama 3 detik.
  digitalWrite(LED_PIN, HIGH);
  delay(3000);
  digitalWrite(LED_PIN, LOW);

  Wire.begin(21, 22);

  lcd.init();
  lcd.backlight();

  dht.begin();

  if (!rtc.begin()) {
    lcd.setCursor(0, 0);
    lcd.print("RTC ERROR!");
    Serial.println("RTC tidak ditemukan!");

    while (true) {
      aturRelay(false);
      digitalWrite(LED_PIN, LOW);
      delay(100);
    }
  }

  // WAKTU AWAL SIMULASI
  // Diatur ke 18:00 setiap ESP32 di-reset.
  rtc.adjust(DateTime(2026, 10, 29, 18, 0, 0));

  lcd.setCursor(0, 0);
  lcd.print("Pengusir Nyamuk");
  lcd.setCursor(0, 1);
  lcd.print("Memulai...");
  delay(1500);
}

// ===== LOOP UTAMA =====
void loop() {
  DateTime sekarang = rtc.now();

  int jam = sekarang.hour();
  int menit = sekarang.minute();

  bool jadwalAktif = dalamJadwal(jam, menit);
  bool adaGerakan = digitalRead(PIR_PIN) == HIGH;

  // Baca DHT22 setiap 2 detik
  if (millis() - waktuBacaSensor >= 2000 ||
      waktuBacaSensor == 0) {

    waktuBacaSensor = millis();

    float t = dht.readTemperature();
    float h = dht.readHumidity();

    sensorDHTValid = !isnan(t) && !isnan(h);

    if (sensorDHTValid) {
      suhu = t;
      kelembapan = h;
    }
  }

  // Relay aktif jika jadwal aktif DAN PIR mendeteksi gerakan
  bool relayAktif = jadwalAktif && adaGerakan;

  aturRelay(relayAktif);

  // LED mengikuti status relay
  digitalWrite(LED_PIN, relayAktif ? HIGH : LOW);

  // Buzzer berbunyi sesaat ketika status berubah
  if (relayAktif != statusRelaySebelumnya) {
    tone(BUZZER_PIN, 2000, 200);
    statusRelaySebelumnya = relayAktif;

    Serial.println(relayAktif
      ? "Relay ON: jadwal aktif dan gerakan terdeteksi"
      : "Relay OFF");
  }

  // Informasi Serial Monitor
  Serial.print("Waktu: ");

  if (jam < 10) Serial.print('0');
  Serial.print(jam);
  Serial.print(':');

  if (menit < 10) Serial.print('0');
  Serial.print(menit);

  Serial.print(" | Jadwal: ");
  Serial.print(jadwalAktif ? "AKTIF" : "NONAKTIF");

  Serial.print(" | PIR: ");
  Serial.print(adaGerakan ? "GERAKAN" : "TIDAK ADA");

  Serial.print(" | Relay: ");
  Serial.print(relayAktif ? "ON" : "OFF");

  if (sensorDHTValid) {
    Serial.print(" | Suhu: ");
    Serial.print(suhu, 1);
    Serial.print(" C | RH: ");
    Serial.print(kelembapan, 1);
    Serial.print("%");
  } else {
    Serial.print(" | DHT22 belum valid");
  }

  Serial.println();

  // Perbarui LCD setiap 500 ms
  if (millis() - waktuLCD >= 500) {
    waktuLCD = millis();

    lcd.setCursor(0, 0);

    if (sensorDHTValid) {
      lcd.print("T:");
      lcd.print(suhu, 1);
      lcd.print((char)223);
      lcd.print("C H:");
      lcd.print(kelembapan, 0);
      lcd.print("% ");
    } else {
      lcd.print("Sensor DHT error");
    }

    lcd.setCursor(0, 1);

    if (jam < 10) lcd.print('0');
    lcd.print(jam);
    lcd.print(':');

    if (menit < 10) lcd.print('0');
    lcd.print(menit);

    lcd.print(relayAktif ? " RELAY:ON " : " RELAY:OFF");
  }

  delay(100);
}
